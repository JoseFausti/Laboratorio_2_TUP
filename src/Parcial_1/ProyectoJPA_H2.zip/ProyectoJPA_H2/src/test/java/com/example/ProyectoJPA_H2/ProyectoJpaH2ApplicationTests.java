package com.example.ProyectoJPA_H2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoJpaH2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
